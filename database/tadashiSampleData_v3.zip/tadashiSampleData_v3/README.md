# Sample Data for Tadashi

Zip folder contains json files to populate sample data for the tadashi API. Data and information is fabricated and not representative of the real-world.

## Setup

To begin using the sample data, proceed as follows:

1. Install MongoDBCompass
2. Instance a connection a local database on your machine
3. Initiate the tadashi API with a URI pointed to your local DB
4. Navigate to the `tadashi` database within MongoDBCompass
5. Import json files into the same name schemas (i.e. users.json to users)
6. Test validity using endpoints provided within the Postman collection.

## Usage

Once data has been populated, it should be working and data should be shown from Postman responses. All users within this sample set have been given a password of `password` for testing purposes.

## Warning

Do not deploy with the sample data present. Sample data is for local testing purposes only and presents a security risk if deployed to a live database.
